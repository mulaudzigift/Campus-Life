document.addEventListener('DOMContentLoaded', (event) => {
    const chartData = {
        researchData: {
            labels: ["Big Data Analysis I", "Software Engineering II", "Project Management", "Programming III", "Networking"],
            datasets: [{
                label: "Research Scores",
                data: [85, 90, 78, 88, 93]
            }]
        },
        assignmentData: {
            labels: ["Big Data Analysis I Assignment", "Software Engineering II Assignment", "Project Management Assignment", "Networking Assignment", "Programming III Assignment"],
            datasets: [{
                label: "Assignment Scores",
                data: [68, 89, 79, 85, 89]
            }]
        },
        semesterTestData: {
            labels: ["Big Data Analysis I Test", "Software Engineering II Test", "Project Management Test", "Networking Test", "Programming III Test"],
            datasets: [{
                label: "Semester Test Scores",
                data: [74, 86, 80, 50, 65]
            }]
        },
        classTestData: {
            labels: ["Big Data Analysis I Test II", "Software Engineering II Test II", "Project Management Test II", "Networking Test II", "Programming III Test II"],
            datasets: [{
                data: [96, 82, 82, 80, 72]
            }]
        },
        clubsData: {
            labels: ["Drama Club", "Brother's keepers Club", "Enectus Club", "Astronomy Club", "Bible study Club"],
            datasets: [{
                label: "Club Participation",
                data: [18, 98, 85, 61, 90]
            }]
        },
        sportsData: {
            labels: ["Football", "Chess", "Rugby", "Hockey", "Karate"],
            datasets: [{
                label: "Sports Participation",
                data: [88, 35, 50, 42, 27]
            }]
        },
        religionData: {
            labels: ["Christianity", "Islam", "Roman", "African Religion", "Catholic"],
            datasets: [{
                label: "Religious Activities",
                data: [100, 20, 35, 0, 13]
            }]
        },
        otherEngagementsData: {
            labels: ["Politics", "Clubbing", "Community Service", "Seminars/Webinars", "Chillers"],
            datasets: [{
                label: "Other Engagements",
                data: [25, 0, 70, 45, 0]
            }]
        },
        clinicVisitsData:{
            labels: ["Visit 1", "Visit 2", "Visit 3", "Visit 4", "Visit 5"],
            datasets: [{
                label: "Clinic Visits",
                data: [
                    { x: "Visit 1", y: 12, diagnosis: "Cold" },
                    { x: "Visit 2", y: 19, diagnosis: "Flu" },
                    { x: "Visit 3", y: 8, diagnosis: "Modified Allergy" },
                    { x: "Visit 4", y: 5, diagnosis: "Asthma" },
                    { x: "Visit 5", y: 2, diagnosis: "Headache" }
                ]
            }]
        },
        seasonalDistributionData: {
            labels: ["Spring", "Summer", "Fall", "Winter"],
            datasets: [{
                label: "Seasonal Distribution",
                data: [
                    { x: "Spring", y: 30, diagnosis: "Allergies" },
                    { x: "Summer", y: 40, diagnosis: "Heat Stroke" },
                    { x: "Fall", y: 20, diagnosis: "Flu" },
                    { x: "Winter", y: 10, diagnosis: "Cold" }
                ]
            }]
        }
    };

    function analyzeData(data) {
        const insights = {};

        for (const key in data) {
            const dataset = data[key].datasets[0].data;
            const highestIndex = dataset.findIndex(d => d === Math.max(...dataset));
            const lowestIndex = dataset.findIndex(d => d === Math.min(...dataset));
            const highest = dataset[highestIndex];
            const lowest = dataset[lowestIndex];
            const highestLabel = data[key].labels[highestIndex];
            const lowestLabel = data[key].labels[lowestIndex];

            switch (key) {
                case 'researchData':
                case 'assignmentData':
                case 'semesterTestData':
                case 'classTestData':
                    insights[key] = `Highest module: ${highestLabel} (${highest}), Lowest module: ${lowestLabel} (${lowest}).`;
                    break;
                case 'clubsData':
                    insights[key] = `Most participated club: ${highestLabel} (${highest}), Least participated club: ${lowestLabel} (${lowest}).`;
                    break;
                case 'sportsData':
                    insights[key] = `Most participated sport: ${highestLabel} (${highest}), Least participated sport: ${lowestLabel} (${lowest}).`;
                    break;
                case 'religionData':
                    insights[key] = `Most engaged religious activity: ${highestLabel} (${highest}), Least engaged religious activity: ${lowestLabel} (${lowest}).`;
                    break;
                case 'otherEngagementsData':
                    insights[key] = `Most engaged activity: ${highestLabel} (${highest}), Least engaged activity: ${lowestLabel} (${lowest}).`;
                    break;
                case 'clinicVisitsData':
                    insights[key] = dataset.map(d => `${d.x} (${d.y} visits) - ${d.diagnosis}`).join('<br>');
                    break;
                case 'seasonalDistributionData':
                    insights[key] = dataset.map(d => `In ${d.x}, the student often had ${d.diagnosis} (${d.y} cases)`).join('<br>');
                    break;
            }
        }
        return insights;
    }

    function displayInsights(insights) {
        let insightsText = '';
        for (const key in insights) {
            insightsText += `<p>${key}: ${insights[key]}</p>`;
        }
        return insightsText;
    }

    var i = 0;
    var insightsText = displayInsights(analyzeData(chartData));
    var speed = 30; /* Increased speed/duration of the effect in milliseconds */

    function typeWriter() {
        if (i < insightsText.length) {
            if (insightsText.charAt(i) === '<') {
                const endIndex = insightsText.indexOf('>', i);
                document.querySelector('.demo').innerHTML += insightsText.substring(i, endIndex + 1);
                i = endIndex + 1;
            } else {
                document.querySelector('.demo').innerHTML += insightsText.charAt(i);
                i++;
            }
            setTimeout(typeWriter, speed);
        }
    }

    const hintButton = document.getElementById('hintButton');
    const analysisContainer = document.getElementById('analysisContainer');
    const analysis = document.getElementById('Analysis');

    hintButton.addEventListener('click', () => {
        if (analysisContainer.style.display === 'none') {
            analysisContainer.style.display = 'block';
            document.querySelector('.demo').innerHTML = ''; // Clear previous content
            i = 0; // Reset index for typing effect
            typeWriter(); // Start typing effect
            analysis.textContent = `Analysis: Clicked on "Hint" button`;
        } else {
            analysisContainer.style.display = 'none';
        }
    });
});