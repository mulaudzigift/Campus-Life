// Function to open a specific page and initialize the map if necessary
function openPage(pageName, elmnt, color) {
    hideAllElementsByClass("tabcontent");
    removeBackgroundFromAllElementsByClass("tablink");

    document.getElementById(pageName).style.display = "block";
    elmnt.style.backgroundColor = color;

    if (pageName === 'Analytics') {
        initializeMap();
    }
}

// Function to hide all elements of a given class
function hideAllElementsByClass(className) {
    const elements = document.getElementsByClassName(className);
    Array.from(elements).forEach(element => {
        element.style.display = "none";
    });
}

// Function to remove background color from all elements of a given class
function removeBackgroundFromAllElementsByClass(className) {
    const elements = document.getElementsByClassName(className);
    Array.from(elements).forEach(element => {
        element.style.backgroundColor = "";
    });
}

// Function to initialize the map
function initializeMap() {
    const map = L.map('map').setView([-28.7467, 24.765], 14);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 18,
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);

    const markers = [
        { lat: -28.74490987731329, lon: 24.766152914691638, color: 'blue', text: 'Sol Plaatje University - North Campus: Luka Jantjie House', count: 10 },
        { lat: -28.748514939002607, lon: 24.765289243215463, color: 'red', text: 'Sol Plaatje University Central Campus', count: 5 },
        { lat: -28.749147516889195, lon: 24.7645221314844, color: 'green', text: 'Moroka Hall of Residence', count: 8 },
        { lat: -28.749457305074696, lon: 24.764961277314995, color: 'yellow', text: 'Sol Plaatje University Library & Student Resource Centre', count: 12 },
        { lat: -28.749147516889195, lon: 24.7645221314844, color: 'purple', text: 'Sol Plaatje University- Auditorium', count: 4 },
        { lat: -28.74910574377625, lon: 24.764365826904477, color: 'orange', text: 'Academic Building SPU', count: 6 },
        { lat: -28.748653062783955, lon: 24.763962154467002, color: 'cyan', text: 'Gym', count: 7 },
        { lat: -28.748888221988214, lon: 24.764267926281104, color: 'magenta', text: "Mpho's Food Corner", count: 3 },
        { lat: -28.739409345942967, lon: 24.763029696044615, color: 'red', text: 'Quuens Club- GRooveee', count: 0 }
    ];

    markers.forEach(marker => {
        const circleMarker = L.circleMarker([marker.lat, marker.lon], {
            radius: 8 + marker.count,
            color: marker.color,
            opacity: 0.6
        }).addTo(map);
        circleMarker.bindPopup(`<strong>${marker.text}</strong><br>Visits: ${marker.count}`);
    });

    const group = new L.featureGroup(markers.map(marker => L.marker([marker.lat, marker.lon])));
    map.fitBounds(group.getBounds());
}

// Function to handle collapsible elements
function handleCollapsible() {
    const coll = document.getElementsByClassName("collapsible");
    Array.from(coll).forEach(element => {
        element.addEventListener("click", function() {
            this.classList.toggle("active");
            const content = this.nextElementSibling;
            content.style.maxHeight = content.style.maxHeight ? null : content.scrollHeight + "px";
        });
    });
}

// Function to create charts
function createChart(chartId, chartType, data, customConfig = {}) {
    const ctx = document.getElementById(chartId)?.getContext('2d');
    if (!ctx) {
        console.error(`Element with id ${chartId} not found`);
        return;
    }

    let datasets = data.datasets.map(dataset => {
        let modifiedData = dataset.data.map(point => {
            // Apply any custom data modifications here
            if (customConfig.modifyData) {
                return customConfig.modifyData(point);
            } else {
                return point;
            }
        });

        return {
            ...dataset,
            data: modifiedData
        };
    });

    let defaultConfig = {
        responsive: true,
        plugins: {
            legend: { position: 'top' },
            title: { display: true, text: 'Chart Title' }
        }
    };

    if (customConfig.tooltipCallback) {
        defaultConfig.plugins.tooltip = {
            callbacks: {
                label: customConfig.tooltipCallback
            }
        };
    }

    new Chart(ctx, {
        type: chartType,
        data: {
            labels: data.labels,
            datasets: datasets
        },
        options: { ...defaultConfig, ...customConfig.options }
    });
}
    

// Chart data
const chartData = {
    researchData: {
        labels: ["Big Data Analysis I", "Software Engineering II", "Project Management", "Programming III", "Networking"],
        datasets: [{
            label: "Research Scores",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)", "rgba(255,159,64,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)", "rgba(255,159,64,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [85, 90, 78, 88, 93]
        }]
    },
    assignmentData: {
        labels: ["Big Data Analysis I Assignment", "Software Engineering II Assignment", "Project Management Assignment", "Networking Assignment", "Programming III Assignment"],
        datasets: [{
            label: "Assignment Scores",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)", "rgba(255,159,64,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)", "rgba(255,159,64,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [68, 89, 79, 85, 89]
        }]
    },
    semesterTestData: {
        labels: ["Big Data Analysis I Test", "Software Engineering II Test", "Project Management Test", "Networking Test", "Programming III Test"],
        datasets: [{
            label: "Semester Test Scores",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)", "rgba(255,159,64,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)", "rgba(255,159,64,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [74, 86, 80, 50, 65]
        }]
    },
    classTestData: {
        labels: ["Big Data Analysis I Test II", "Software Engineering II Test II", "Project Management Test II", "Networking Test II", "Programming III Test II"],
        datasets: [{
            label: "Class Test Scores",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)", "rgba(255,159,64,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)", "rgba(255,159,64,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [96, 82, 82, 80, 72]
        }]
    },
    clubsData: {
        labels: ["Drama Club", "Brother's keepers Club", "Enectus Club", "Astronomy Club", "Bible study Club"],
        datasets: [{
            label: "Club Participation",
            backgroundColor: ["rgba(255,205,86,0.2)", "rgba(75,192,192,0.2)", "rgba(153,102,255,0.2)", "rgba(255,99,132,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(255,205,86,1)", "rgba(75,192,192,1)", "rgba(153,102,255,1)", "rgba(255,99,132,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [18, 98, 85, 61, 90]
        }]
    },
    sportsData: {
        labels: ["Football", "Chess", "Rugby", "Hockey", "Karate"],
        datasets: [{
            label: "Sports Participation",
            backgroundColor: ["rgba(54,162,235,0.2)", "rgba(255,205,86,0.2)", "rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)"],
            borderColor: ["rgba(54,162,235,1)", "rgba(255,205,86,1)", "rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)"],
            borderWidth: 1,
            data: [88, 35, 50, 42, 27]
        }]
    },
    religionData: {
        labels: ["Christianity", "Islam", "Roman", "African Religion", "Catholic"],
        datasets: [{
            label: "Religious Activities",
            backgroundColor: ["rgba(153,102,255,0.2)", "rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(255,205,86,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(153,102,255,1)", "rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(255,205,86,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [100, 20, 35, 0, 13]
        }]
    },
    otherEngagementsData: {
        labels: ["Politics", "Clubbing", "Community Service", "Seminars/Webinars", "Chillers"],
        datasets: [{
            label: "Other Engagements",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(153,102,255,0.2)", "rgba(255,205,86,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(153,102,255,1)", "rgba(255,205,86,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [25, 0, 70, 45, 0]
        }]
    },
    clinicVisitsData:{
        labels: ["Visit 1", "Visit 2", "Visit 3", "Visit 4", "Visit 5"],
        datasets: [{
            label: "Clinic Visits",
            backgroundColor: ["rgba(255,159,64,0.2)", "rgba(54,162,235,0.2)", "rgba(255,206,86,0.2)", "rgba(75,192,192,0.2)", "rgba(153,102,255,0.2)"],
            borderColor: ["rgba(255,159,64,1)", "rgba(54,162,235,1)", "rgba(255,206,86,1)", "rgba(75,192,192,1)", "rgba(153,102,255,1)"],
            borderWidth: 1,
            data: [
                { x: "Visit 1", y: 12, diagnosis: "Cold" },
                { x: "Visit 2", y: 19, diagnosis: "Flu" },
                { x: "Visit 3", y: 8, diagnosis: "Modified Allergy" },
                { x: "Visit 4", y: 5, diagnosis: "Asthma" },
                { x: "Visit 5", y: 2, diagnosis: "Headache" }
            ]
        }]
    },
    seasonalDistributionData: {
        labels: ["Spring", "Summer", "Fall", "Winter"],
        datasets: [{
            label: "Seasonal Distribution",
            backgroundColor: ["rgba(75,192,192,0.2)", "rgba(255,99,132,0.2)", "rgba(255,205,86,0.2)", "rgba(54,162,235,0.2)"],
            borderColor: ["rgba(75,192,192,1)", "rgba(255,99,132,1)", "rgba(255,205,86,1)", "rgba(54,162,235,1)"],
            borderWidth: 1,
            data: [
                { x: "Spring", y: 30, diagnosis: "Allergies" },
                { x: "Summer", y: 40, diagnosis: "Heat Stroke" },
                { x: "Fall", y: 20, diagnosis: "Flu" },
                { x: "Winter", y: 10, diagnosis: "Cold" }
            ]
        }]
    }
};

const visitChartConfig = {
    modifyData: (point) => {
        if (point.x === "Visit 3") {
            return { x: point.x, y: 8, diagnosis: "Modified Allergy" };
        } else {
            return point;
        }
    },
    tooltipCallback: function (context) {
        const { x, y, diagnosis } = context.raw;
        return `Visit: ${x}, Count: ${y}, Diagnosis: ${diagnosis}`;
    }
};

// Initialize the default tab and collapsible elements
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById("defaultOpen").click();
    handleCollapsible();

    createChart('researchChart', 'bar', chartData.researchData);
    createChart('assignmentChart', 'line', chartData.assignmentData);
    createChart('semesterTestChart', 'pie', chartData.semesterTestData);
    createChart('classTestChart', 'radar', chartData.classTestData);
    createChart('clubsChart', 'bar', chartData.clubsData);
    createChart('sportsChart', 'line', chartData.sportsData);
    createChart('religionChart', 'pie', chartData.religionData);
    createChart('otherEngagementsChart', 'radar', chartData.otherEngagementsData);
    createChart('clinicVisitsChart', 'bar', chartData.clinicVisitsData, {
        tooltipCallback: function(context) {
            const { x, y, diagnosis } = context.raw;
            return `Visit: ${x}, Count: ${y}, Diagnosis: ${diagnosis}`;
        }
    });
    createChart('seasonalDistributionChart', 'line', chartData.seasonalDistributionData, {
        tooltipCallback: function (context) {
            const { x, y, diagnosis } = context.raw;
            return `Season: ${x}, Count: ${y}, Diagnosis: ${diagnosis}`;
        }
    });
});

